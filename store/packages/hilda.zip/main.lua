local mod=...
local function loadData(path)
 local src,err=mod:read(path); if type(src)!="string" then error("missing "..path..": "..tostring(err)) end
 local fn,e=load(src,"@"..path); if not fn then error(e) end
 local ok,data=pcall(fn); if not ok then error(data) end; return data
end
local META={id="HILDA",behaviorId="HILDA",label="Hilda",category="Pokemon Trainers",section="POKEMON",height=20.0,profile="WOW_FBX",armRestDeg=0,modelYawOffset=0,dynamicAtlas="hilda_face",data="data/hilda_model.lua",atlas="assets/hilda_atlas_neutral.png",atlasFrames={"assets/hilda_atlas_neutral.png","assets/hilda_atlas_half.png","assets/hilda_atlas_blink.png","assets/hilda_atlas_smile.png"}}
local ATLAS_PATHS={"assets/hilda_atlas_neutral.png","assets/hilda_atlas_half.png","assets/hilda_atlas_blink.png","assets/hilda_atlas_smile.png"}
local imageMap={}
for _,path in ipairs(ATLAS_PATHS) do imageMap[path]=mod.assets:image(path) end
local function hydrate(def)
 local out={}; for k,v in pairs(def or {}) do out[k]=v end
 if out.data then out._runtimeData=loadData(out.data) end
 out.atlasImages=imageMap; return out
end
local def=hydrate(META)
if type(META.variants)=="table" then def.variants={}; for i,v in ipairs(META.variants) do def.variants[i]=hydrate(v) end end
local selectorIdle=nil
mod.exports.character={id="HILDA",def=def,selectorIdle=selectorIdle}

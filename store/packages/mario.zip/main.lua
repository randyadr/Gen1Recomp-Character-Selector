local mod=...
local function loadData(path)
 local src,err=mod:read(path); if type(src)!="string" then error("missing "..path..": "..tostring(err)) end
 local fn,e=load(src,"@"..path); if not fn then error(e) end
 local ok,data=pcall(fn); if not ok then error(data) end; return data
end
local META={id="MARIO",behaviorId="MARIO",label="Mario (SM64 / SA64)",category="Random",section="MISC",height=19.5,profile="MARIO_SM64",armRestDeg=0,modelYawOffset=0,dynamicAtlas="marioBlink",data="data/mario_sm64_model.lua",atlas="assets/mario_sm64_atlas.png",atlasFrames={"assets/mario_sm64_atlas.png","assets/mario_sm64_atlas_half.png","assets/mario_sm64_atlas_closed.png"}}
local ATLAS_PATHS={"assets/mario_sm64_atlas.png","assets/mario_sm64_atlas_half.png","assets/mario_sm64_atlas_closed.png"}
local imageMap={}
for _,path in ipairs(ATLAS_PATHS) do imageMap[path]=mod.assets:image(path) end
local function hydrate(def)
 local out={}; for k,v in pairs(def or {}) do out[k]=v end
 if out.data then out._runtimeData=loadData(out.data) end
 out.atlasImages=imageMap; return out
end
local def=hydrate(META)
if type(META.variants)=="table" then def.variants={}; for i,v in ipairs(META.variants) do def.variants[i]=hydrate(v) end end
local selectorIdle=nil
mod.exports.character={id="MARIO",def=def,selectorIdle=selectorIdle}

local mod=...
local function loadData(path)
 local src,err=mod:read(path); if type(src)~="string" then error("missing "..path..": "..tostring(err)) end
 local fn,e=load(src,"@"..path); if not fn then error(e) end
 local ok,data=pcall(fn); if not ok then error(data) end; return data
end
local META={id="CLOUD",behaviorId="CLOUD",label="Cloud",section="MISC",height=20,profile="CLOUD",armRestDeg=0,data="data/cloud_model.lua",atlas="assets/cloud_atlas.png"}
local ATLAS_PATHS={"assets/cloud_atlas.png"}
local imageMap={}
for _,path in ipairs(ATLAS_PATHS) do imageMap[path]=mod.assets:image(path) end
local function hydrate(def)
 local out={}; for k,v in pairs(def or {}) do out[k]=v end
 if out.data then out._runtimeData=loadData(out.data) end
 out.atlasImages=imageMap; return out
end
local def=hydrate(META)
if type(META.variants)=="table" then def.variants={}; for i,v in ipairs(META.variants) do def.variants[i]=hydrate(v) end end
local selectorIdle=nil
mod.exports.character={id="CLOUD",def=def,selectorIdle=selectorIdle}

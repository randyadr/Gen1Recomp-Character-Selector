local mod=...
local function loadData(path)
 local src,err=mod:read(path); if type(src)~="string" then error("missing "..path..": "..tostring(err)) end
 local fn,e=load(src,"@"..path); if not fn then error(e) end
 local ok,data=pcall(fn); if not ok then error(data) end; return data
end
local META={id="SONIC",behaviorId="SONIC",label="Sonic the Hedgehog",section="MISC",height=18.5,profile="WOW_FBX",armRestDeg=0,modelYawOffset=0,data="data/sonic_model.lua",atlas="assets/sonic_atlas.png",variants={{label="MODERN SONIC",data="data/sonic_model.lua",atlas="assets/sonic_atlas.png",profile="WOW_FBX",height=18.5,modelYawOffset=0,projectYawOffset=0,sourceYaw180=false,postSkinZUp=false},{label="CLASSIC FIGHTERS",data="data/sonic_classic_model.lua",atlas="assets/sonic_classic_atlas.png",profile="WOW_FBX",height=18.5,modelYawOffset=0,projectYawOffset=0,sourceYaw180=false,postSkinZUp=false}}}
local ATLAS_PATHS={"assets/sonic_atlas.png","assets/sonic_classic_atlas.png"}
local imageMap={}
for _,path in ipairs(ATLAS_PATHS) do imageMap[path]=mod.assets:image(path) end
local function hydrate(def)
 local out={}; for k,v in pairs(def or {}) do out[k]=v end
 if out.data then out._runtimeData=loadData(out.data) end
 out.atlasImages=imageMap; return out
end
local def=hydrate(META)
if type(META.variants)=="table" then def.variants={}; for i,v in ipairs(META.variants) do def.variants[i]=hydrate(v) end end
local selectorIdle=nil
mod.exports.character={id="SONIC",def=def,selectorIdle=selectorIdle}

local mod=...
local function loadData(path)
 local src,err=mod:read(path); if type(src)!="string" then error("missing "..path..": "..tostring(err)) end
 local fn,e=load(src,"@"..path); if not fn then error(e) end
 local ok,data=pcall(fn); if not ok then error(data) end; return data
end
local META={id="NARUTO",behaviorId="NARUTO",label="Naruto",category="Anime",section="ANIME",height=20.5,profile="NARUTO_MIXAMO",armRestDeg=0,modelYawOffset=0,projectYawOffset=0,sourceYaw180=true,dynamicAtlas="blink",data="data/naruto_model.lua",atlas="assets/naruto_atlas_open.png",atlasFrames={"assets/naruto_atlas_open.png","assets/naruto_atlas_close00.png"}}
local ATLAS_PATHS={"assets/naruto_atlas_open.png","assets/naruto_atlas_close00.png"}
local imageMap={}
for _,path in ipairs(ATLAS_PATHS) do imageMap[path]=mod.assets:image(path) end
local function hydrate(def)
 local out={}; for k,v in pairs(def or {}) do out[k]=v end
 if out.data then out._runtimeData=loadData(out.data) end
 out.atlasImages=imageMap; return out
end
local def=hydrate(META)
if type(META.variants)=="table" then def.variants={}; for i,v in ipairs(META.variants) do def.variants[i]=hydrate(v) end end
local selectorIdle=nil
mod.exports.character={id="NARUTO",def=def,selectorIdle=selectorIdle}
